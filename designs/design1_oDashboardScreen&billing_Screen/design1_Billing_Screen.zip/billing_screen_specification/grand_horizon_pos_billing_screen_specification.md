# Grand Horizon / URQR POS · Billing Screen Specification
## Frontend Engineering Design Tokens, Functional Logic & Component Specification

---

### 1. Architectural Overview & Context
This specification documents the **Grand Horizon / URQR Manager POS Billing Screen** (`pos/billing`), matching the HTML implementation in `DOCUMENT_4` and screen capture in `IMAGE_41`. This application serves high-velocity restaurant cashier and counter operations with touch-and-keyboard accessibility, sub-millisecond cart computation, real-time category filtering, and tender handling.

---

### 2. Design Tokens & Color Palette

All colors conform to the warm sepia, cream, and roasted coffee aesthetic of the **Grand Horizon / URQR POS** brand:

| Token Name | Custom Property | Hex Code | Purpose / Usage |
| :--- | :--- | :--- | :--- |
| **Canvas Background** | `--color-bg` | `#F5EEE0` | Root layout viewport background, product grid well |
| **Surface (Card & Header)** | `--color-surface` | `#FFFDF8` | Top header, cart summary rail, product cards |
| **Surface Alt / Well** | `--color-surface-alt` | `#FAF3E6` | Search input fill, inactive category pill fill, table well |
| **Primary Border** | `--color-border` | `#E4D8C3` | 1px card outlines, divider lines, button borders |
| **Subtle Border** | `--color-border-subtle` | `#EDE4D4` | Internal card separations, table row rules |
| **Primary Brand Brown** | `--color-primary` | `#8B5E3C` | Active pill borders, focus rings, interactive elements |
| **Primary Brand Dark** | `--color-primary-dark` | `#5C3D26` | Active navigation highlights, primary CTAs, emblem container |
| **Body Text Primary** | `--color-text` | `#3B2A1E` | Headlines, product titles, currency totals |
| **Secondary Text** | `--color-text-secondary` | `#7A6A5A` | Subtitles, status labels, unit descriptors |
| **Muted Text / Placeholder** | `--color-text-muted` | `#9E8E7E` | Input placeholder copy, shortcut badges |
| **Success Status** | `--color-success` | `#3F6B3A` | "Online" network pill, "In stock" badge |
| **Success Background** | `--color-success-bg` | `#EEF3E8` | Background tint for stock and network pills |
| **Warning Status** | `--color-warning` | `#B45309` | "Low stock" status badge text |
| **Warning Background** | `--color-warning-bg` | `#FDF1E1` | Background tint for low stock badge |
| **Error / Sold Out** | `--color-error` | `#B91C1C` | "Sold out" status badge text |
| **Error Background** | `--color-error-bg` | `#FEE2E2` | Background tint for sold out badge |
| **Disabled Element** | `--color-disabled` | `#D9CDB8` | Inactive/disabled CTA buttons, cart empty placeholder |

---

### 3. Layout Grid & Structural Hierarchy

```
+----------------------------------------------------------------------------------------------------+
| HEADER (72px fixed height)                                                                         |
| [≡ Hamburger]  [🍴 GRAND HORIZON | URQR POS v2.4]    [🔍 Search items... F2]    [🟢 Online] [🕒 Date]|
+--------------------------+------------------------------------------------------+------------------+
| SIDEBAR (240px or 72px)  | MAIN PRODUCT WORKSPACE (flex-1)                      | ORDER SUMMARY    |
|                          | Category Pills: [All] [Starters] [Main Course] ...   | (380px fixed)    |
| [🧾 Billing] (Active)    | Section Header: ALL ITEMS (9 products)               | Order #8247      |
| [📊 Dashboard]           |                                                      | Cart Item List   |
|                          | [ Product ]  [ Product ]  [ Product ]  [ Product ]   | Subtotal / Tax   |
|                          | [ Product ]  [ Product ]  [ Product ]  ...           | Grand Total      |
| [🚪 Logout]              |                                                      | [PAYMENT CTA]    |
+--------------------------+------------------------------------------------------+------------------+
```

1. **Header Bar**:
   - `height: 72px`, fixed at `top: 0`, `z-index: 30`.
   - Brand container: `40px × 40px` rounded `8px`, `#5C3D26` fill, cutlery vector icon.
   - Global Search input: `padding-left: 42px`, `height: 42px`, keyboard badge `F2`.
   - Network status pill: `#EEF3E8` fill with pulsating `#3F6B3A` dot and `Online` label.
   - Date pill: `Thu, 26 Nov, 2026` with clock icon.

2. **Left Navigation Sidebar**:
   - Fixed below header: `top: 72px; bottom: 0; left: 0; width: 240px`.
   - Collapsible state: `width: 72px` (icons only) or `width: 0` (hidden).
   - Links: **Billing** (active with `#5C3D26` fill), **Dashboard**, and pinned bottom **Logout**.

3. **Catalog & Product Grid Area**:
   - Filter chips: `height: 36px`, rounded `9999px`, active chip with `#3B2A1E` dark fill.
   - Product Grid: `grid-template-columns: repeat(auto-fill, minmax(220px, 1fr))`, `gap: 16px`.
   - Product Card anatomy:
     - Placeholder aspect ratio image container (`height: 140px`, `#EFE9DC` tint).
     - Title: `Newsreader`/`Inter` SemiBold 14px.
     - Price: tabular-nums (e.g. `₹18.50`).
     - Status Tag: `In stock` (green), `Low stock` (amber), `Sold out` (rose).
     - Action CTA: `+ Add` button (`#FFFDF8` with `#E4D8C3` border, hover `#8B5E3C`).

4. **Order Summary Rail**:
   - Fixed width `380px` on right margin.
   - Header with active dynamic order number (`Order #8247`).
   - Line items listing quantity badge, item name, unit pricing, unit modifier buttons (`-` and `+`), and trash delete icon.
   - Ledger breakdown:
     - Subtotal (sum of `quantity * unitPrice`)
     - Tax Breakdown accordion (5% GST split: 2.5% CGST + 2.5% SGST)
     - Grand Total in large 28px bold tabular typography.
   - Action controls: `Preview` receipt button and `SELECT PAYMENT METHOD` primary CTA.

---

### 4. Interactive Operations & State Machine

#### A. Cart Management & Arithmetic
- **Add to Cart**: If item ID exists, increment `item.quantity += 1`; otherwise insert line item `{ id, name, price, quantity: 1 }`.
- **Decrement / Remove**: When clicking `-`, decrement `quantity`. If `quantity <= 0`, prompt or remove line item.
- **Tax Calculation Formula**:
  $$\text{Subtotal} = \sum (\text{item.price} \times \text{item.quantity})$$
  $$\text{CGST} = \text{round}(\text{Subtotal} \times 0.025, 2)$$
  $$\text{SGST} = \text{round}(\text{Subtotal} \times 0.025, 2)$$
  $$\text{Grand Total} = \text{Subtotal} + \text{CGST} + \text{SGST}$$

#### B. Search & Category Filter
- **Search (F2)**: Real-time debounced text query matching against `product.name` and `product.category`.
- **Category Filter**: Filtering on `All`, `Starters`, `Main Course`, `Desserts`, `Drinks`, `Soups`, `Salads`.

#### C. Payment Modal Workflow
- Triggered by clicking `SELECT PAYMENT METHOD` when `cart.length > 0`.
- **Payment Tenders**:
  1. **Cash**: Displays keypad, quick cash pills (`Exact`, `₹100`, `₹500`, `₹2,000`), calculates `Change Due = Cash Received - Grand Total`.
  2. **UPI / QR**: Generates simulated QR code and deep-link payload.
  3. **Card / EDC Terminal**: Triggers POS chip reader sync state.
- **Confirm Payment**: Emits receipt number, creates completed record, clears cart, and resets view for next transaction.

#### D. Keyboard Shortcuts
- `F2`: Set focus to Global Search input.
- `Escape`: Close any active modal, popover, or drawer.
- `Enter` (inside payment cash input): Submit payment if `amountReceived >= grandTotal`.

---

### 5. Accessibility & Engineering Checklist
- **Contrast**: All text values exceed WCAG AA ratio 4.5:1 (`#3B2A1E` on `#FFFDF8` achieves 12.4:1).
- **Tabindex & Focus**: All buttons, inputs, and interactive chips feature a distinct focus ring (`outline: 2px solid #8B5E3C; outline-offset: 2px`).
- **Touch Ergonomics**: All tap targets (quantity steppers, product cards, category chips) adhere to minimum `44 × 44px` touch zones.
