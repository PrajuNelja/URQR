---
name: Warm Espresso POS
colors:
  surface: '#171310'
  surface-dim: '#171310'
  surface-bright: '#3e3834'
  surface-container-lowest: '#110d0a'
  surface-container-low: '#1f1b17'
  surface-container: '#231f1b'
  surface-container-high: '#2e2926'
  surface-container-highest: '#393430'
  on-surface: '#ebe1db'
  on-surface-variant: '#d9c2b5'
  inverse-surface: '#ebe1db'
  inverse-on-surface: '#352f2c'
  outline: '#a18d81'
  outline-variant: '#534439'
  surface-tint: '#ffb784'
  primary: '#ffb784'
  on-primary: '#4f2500'
  primary-container: '#cc7e41'
  on-primary-container: '#451f00'
  inverse-primary: '#904d13'
  secondary: '#f9ba78'
  on-secondary: '#492900'
  secondary-container: '#673d03'
  on-secondary-container: '#e5a968'
  tertiary: '#6bd6e5'
  on-tertiary: '#00363d'
  tertiary-container: '#259fae'
  on-tertiary-container: '#002f35'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdcc6'
  primary-fixed-dim: '#ffb784'
  on-primary-fixed: '#301400'
  on-primary-fixed-variant: '#713700'
  secondary-fixed: '#ffdcbc'
  secondary-fixed-dim: '#f9ba78'
  on-secondary-fixed: '#2c1700'
  on-secondary-fixed-variant: '#673d03'
  tertiary-fixed: '#95f1ff'
  tertiary-fixed-dim: '#6bd6e5'
  on-tertiary-fixed: '#001f24'
  on-tertiary-fixed-variant: '#004f57'
  background: '#171310'
  on-background: '#ebe1db'
  surface-variant: '#393430'
  surface-subtle: '#1c1612'
  surface-card: '#241c17'
  surface-elevated: '#2b221b'
  border-card: '#3d2f26'
  border-active: '#c87a3e'
  text-primary: '#fdfaf6'
  text-secondary: '#baa99b'
  text-muted: '#7d6e64'
  status-success: '#22c55e'
  status-warning: '#fb923c'
  status-danger: '#ef4444'
typography:
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
  numeric-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 28px
  numeric-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 0.75rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

# Grand Horizon POS — Warm Espresso Dark Mode Design System

## 1. Overview & Brand Identity
The **Warm Espresso Dark Mode** is a purpose-crafted visual theme designed for fine-dining point-of-sale environments. Combining deep, roasted dark-espresso backgrounds with rich cognac leather accents and warm linen typography.

## 2. Color Palette & Tokens
- **Background Root**: `#14100d`
- **Surface Subtle**: `#1c1612`
- **Surface Card**: `#241c17`
- **Surface Elevated**: `#2b221b`
- **Border Card**: `#3d2f26`
- **Border Active**: `#c87a3e`
- **Brand Primary Cognac**: `#c87a3e`
- **Brand Gold**: `#e5a968`
- **Text Primary**: `#fdfaf6`
- **Text Secondary**: `#baa99b`
- **Text Muted**: `#7d6e64`
- **Status Success**: `#22c55e`
- **Status Warning**: `#fb923c`
- **Status Danger**: `#ef4444`

## 3. Typography
- Display / Headings: Serif (Playfair Display)
- UI / Numerics: Sans-serif (Inter) with Tabular Numbers

## 4. Components
- Catalog Cards: 4:3 image ratio, 14px border radius, subtle hover elevation.
- Cart Line Items: elevated card container (#2b221b), 8px border radius.
