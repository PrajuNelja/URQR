---
name: Obsidian Reserve
colors:
  surface: '#151311'
  surface-dim: '#151311'
  surface-bright: '#3c3936'
  surface-container-lowest: '#100e0c'
  surface-container-low: '#1d1b19'
  surface-container: '#221f1d'
  surface-container-high: '#2c2927'
  surface-container-highest: '#373432'
  on-surface: '#e8e1dd'
  on-surface-variant: '#d4c4b7'
  inverse-surface: '#e8e1dd'
  inverse-on-surface: '#33302d'
  outline: '#9c8e82'
  outline-variant: '#50453b'
  surface-tint: '#f0bd8b'
  primary: '#f2be8c'
  on-primary: '#482904'
  primary-container: '#d4a373'
  on-primary-container: '#5b3912'
  inverse-primary: '#7d562d'
  secondary: '#fab983'
  on-secondary: '#4d2700'
  secondary-container: '#6b3e13'
  on-secondary-container: '#ebab76'
  tertiary: '#74dc9b'
  on-tertiary: '#00391d'
  tertiary-container: '#57c081'
  on-tertiary-container: '#004b29'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdcbd'
  primary-fixed-dim: '#f0bd8b'
  on-primary-fixed: '#2c1600'
  on-primary-fixed-variant: '#623f18'
  secondary-fixed: '#ffdcc2'
  secondary-fixed-dim: '#fab983'
  on-secondary-fixed: '#2e1500'
  on-secondary-fixed-variant: '#683c11'
  tertiary-fixed: '#8ff8b4'
  tertiary-fixed-dim: '#73db9a'
  on-tertiary-fixed: '#00210f'
  on-tertiary-fixed-variant: '#00522d'
  background: '#151311'
  on-background: '#e8e1dd'
  surface-variant: '#373432'
typography:
  display-lg:
    fontFamily: Newsreader
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Newsreader
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Newsreader
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: 0em
  headline-md:
    fontFamily: Newsreader
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: 0em
  title-lg:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.01em
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.04em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-lg: 1.5rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system crafts an atmosphere of quiet luxury, understated authority, and tactical speed for elite hospitality and sommelier-level point of sale environments. It merges warm, tactile brutalism with tailored, editorial minimalism—channeling the ambiance of private cellar tastings, Michelin-starred salon service, and heirloom leather ledgers.

The UI serves front-of-house hospitality professionals, head sommeliers, and floor captains who demand instantaneous tactile feedback in atmospheric, low-lit environments. Visual noise is stripped away in favor of crisp typographic hierarchy, deep obsidian grounding, and warm burnished-amber micro-interactions. The experience instills operational composure, tactile mastery, and uncompromising refinement during peak service velocity.

## Colors

The palette establishes an immersive, low-glare dark canvas using layered obsidian and deep roast coffee tones, accented with warm caramel and aged bronze:

- **Canvas & Backgrounds:** The base layer grounds at `#12100E` (deep obsidian), while the structural layout uses `#181512` (roast coffee wash).
- **Surface Elevation:** 
  - Level 1 (Panels & Sidebar): `#211C18`
  - Level 2 (Order Cards & Item Tiles): `#28221D`
  - Level 3 (Selected Items, Modals, Overlays): `#322B25`
- **Structural Outlines:** `#3E352E` forms crisp, architectural borders without bleeding into visual clutter.
- **Accents:** 
  - Primary `#D4A373` (warm burnished caramel) for primary actions, current totals, active table states, and high-priority toggles.
  - Secondary `#C68B59` (deep amber roast) for secondary active tabs, split-bill handles, and tactile tap states.
- **Typography Tiers:**
  - High-Contrast Primary: `#F5EEE0` (warm clotted cream, guaranteeing WCAG AAA legibility against all dark surfaces).
  - Secondary: `#A89B8C` (taupe-sand) for modifiers, course timing, and item metadata.
  - Muted: `#7A6F63` (aged stone) for structural dividers, inactive modifiers, and micro-labels.
- **Semantic Badges (Dark Atmospheric with Bright Accents):**
  - **Success / Paid / Fired:** Deep forest sage `#1C2E1A` background with `#86EFAC` crisp text and border.
  - **Warning / Hold / In-Kitchen:** Deep charred amber `#38230D` background with `#FBBF24` text.
  - **Error / Void / 86'd:** Deep velvet crimson `#381414` background with `#F87171` text.

## Typography

The typographic hierarchy combines three distinct voices:

1. **Editorial Authority (`Newsreader`):** Used strictly for high-level room headers, check numbers, total monetary sums, and vintage names. It infuses warmth, legacy, and Michelin-star sophistication.
2. **Operational Ergonomics (`Hanken Grotesk`):** Engineered for rapid scanning on active ticket rails, modifier selections, and guest notes. Sharp, neutral, and readable under glare or high-tilt angles.
3. **Ledger Precision (`JetBrains Mono`):** Applied to currency calculations, timestamps, seat indices, table coordinates, and SKU barcodes to guarantee tabular column alignment without numeric jitter.

## Layout & Spacing

The layout is built for high-density touch operations using a modular dual- or triple-pane workspace:

- **Desktop & Large Tablets (Landscape, 1024px+):** A 12-column fixed grid with a static 380px right-hand order rail (`#211C18`), an 80px left persistent action drawer, and a flexible central catalogue/floorplan grid with `1.5rem` gutters.
- **Small Tablets (Portrait, 768px - 1023px):** A 2-column split (60% menu grid / 40% active ticket) using `1rem` gutters and `1.5rem` outer margins.
- **Handheld Mobile POS (360px - 767px):** Full-bleed single column with a sticky floating bottom drawer for the active ticket summary. 44px minimum touch targets are scaled to 52px for all primary actions.
- **Rhythm & Touch Density:** Spacing uses strict 4px base units. Interactive touch items utilize minimum internal paddings of `space-md` (12px) horizontal and `space-sm` (8px) vertical to prevent mistaps during high-speed ordering.

## Elevation & Depth

This design system rejects generic diffuse drop shadows in favor of **structural low-contrast outlines and atmospheric tonal layering**:

- **Layer 0 (Canvas Base):** Deepest background `#12100E` with zero elevation.
- **Layer 1 (Structural Panels):** `#211C18` bordered by a 1px solid `#3E352E` edge. No drop shadow.
- **Layer 2 (Tiles & Cards):** `#28221D` with 1px `#3E352E` borders. On hover/focus, the border transitions to `#C68B59` with a subtle interior amber backlight (`box-shadow: inset 0 0 12px rgba(212, 163, 115, 0.08)`).
- **Layer 3 (Modals, Context Sheets, & Overlays):** `#322B25` lifted with a controlled dark ambient shadow: `0 16px 32px -8px rgba(0, 0, 0, 0.75)`, framed with a distinct 1px border of `#D4A373` at 40% opacity.
- **Pressed & Active Feedback:** Active buttons invert to full caramel fill (`#D4A373`) with zero blur, creating physical, mechanical certainty upon strike.

## Shapes

The shape vocabulary communicates architectural permanence and tailored precision through an intentional **Soft (`1`)** radius profile:

- Base interactive items, catalogue cells, and form fields use `4px` (`0.25rem`) corner radiuses.
- Contained surfaces, order slips, and slide-out payment cards use `rounded-lg` (`8px` / `0.5rem`).
- Large overlay modals use `rounded-xl` (`12px` / `0.75rem`).
- Strict rectangular discipline is maintained for order tickets and modifier grids to replicate high-end ledger tabs and ensure maximum spatial efficiency on screen. Fully round pill buttons are restricted exclusively to operational status indicators.

## Components

### Buttons
- **Primary ("Charge", "Fire Course", "Send"):** Background `#D4A373`, text `#12100E` in `JetBrains Mono` (Bold/600), 4px radius. Tap state darkens to `#C68B59` with instantaneous haptic response.
- **Secondary ("Split Bill", "Transfer Table", "Hold"):** Background `#28221D`, 1px solid border `#3E352E`, text `#F5EEE0`. Hover/active border shifts to `#D4A373`.
- **Tertiary / Destructive ("Void", "Comp"):** Background transparent, 1px solid `#381414`, text `#F87171`. On press: filled `#381414`.

### Input Fields & Keypads
- **Numeric & Barcode Fields:** Surface `#181512` recessed inside `#211C18`, 1px border `#3E352E`. Active focus rings shift border to `#D4A373` with zero glow radius. Text displays at `Newsreader` or `JetBrains Mono` in `#F5EEE0`.
- **Custom POS NumPad:** 3x4 grid of high-contrast tactile tiles (`#28221D`), text centered in `Newsreader` 24px, separated by 1px `#3E352E` grid lines.

### Cards & Catalogue Tiles
- **Menu Item Cards:** Surface `#28221D`, 1px border `#3E352E`. Item title in `Hanken Grotesk` (Semi-bold, `#F5EEE0`), price in `JetBrains Mono` (`#D4A373`), bin/inventory subtext in `JetBrains Mono` (`#7A6F63`).
- **Active State:** When selected, background shifts to `#322B25` with an accent bar along the left edge in solid `#D4A373` (3px wide).

### Chips & Modifiers
- **Tag Toggles ("Rare", "Sub Truffle Fries", "No Dairy"):** Surface `#211C18`, border 1px `#3E352E`, text `#A89B8C` (`JetBrains Mono` 12px).
- **Selected Modifier:** Surface `#322B25`, border 1px `#D4A373`, text `#F5EEE0` with an amber check indicator.

### Lists & Order Receipt Rails
- **Order Line Items:** Alternating subtle row shading (`#211C18` vs transparent).
- **Structure:** Left index in `#7A6F63`, item label in `Hanken Grotesk` `#F5EEE0`, trailing price in `JetBrains Mono` `#F5EEE0`.
- **Seat Dividers:** 1px dashed `#3E352E` border with an editorial pill marker (`Newsreader` Italic: *"Seat 1"*).

### Checkboxes & Radios
- Square 18px footprint with 2px corner radius. Border 1.5px `#7A6F63`. Checked state fills `#D4A373` with `#12100E` checkmark glyph.

### Domain-Specific Components
- **Sommelier Cellar Status Pill:** Displaying bin vintage, real-time bottle count, and optimal serving temperature using `#86EFAC` on `#1C2E1A` badge styling.
- **Table Plan Map Nodes:** Geometric floorplan shapes with `#211C18` fills, `#3E352E` borders, and color-coded interior pips indicating dwell time and course status.