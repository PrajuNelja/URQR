---
name: Grand Breeze POS
colors:
  surface: '#faf8ff'
  surface-dim: '#d0d9fd'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#ebedff'
  surface-container-high: '#e3e7ff'
  surface-container-highest: '#dbe1ff'
  on-surface: '#111a36'
  on-surface-variant: '#45464d'
  inverse-surface: '#262f4c'
  inverse-on-surface: '#eff0ff'
  outline: '#76767e'
  outline-variant: '#c6c6ce'
  surface-tint: '#565d79'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131a33'
  on-primary-container: '#7b83a0'
  inverse-primary: '#bec5e5'
  secondary: '#775a19'
  on-secondary: '#ffffff'
  secondary-container: '#fed488'
  on-secondary-container: '#785a1a'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#002113'
  on-tertiary-container: '#009668'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#bec5e5'
  on-primary-fixed: '#131a33'
  on-primary-fixed-variant: '#3e4660'
  secondary-fixed: '#ffdea5'
  secondary-fixed-dim: '#e9c176'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5d4201'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#faf8ff'
  on-background: '#111a36'
  surface-variant: '#dbe1ff'
typography:
  display-lg:
    fontFamily: Newsreader
    fontSize: 3rem
    fontWeight: '400'
    lineHeight: 3.5rem
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Newsreader
    fontSize: 2rem
    fontWeight: '400'
    lineHeight: 2.5rem
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 2rem
    fontWeight: '500'
    lineHeight: 2.5rem
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Newsreader
    fontSize: 1.5rem
    fontWeight: '500'
    lineHeight: 2rem
  headline-md:
    fontFamily: Newsreader
    fontSize: 1.5rem
    fontWeight: '500'
    lineHeight: 2rem
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: -0.005em
  kpi-metric:
    fontFamily: Hanken Grotesk
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: -0.03em
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1rem
  label-md:
    fontFamily: Hanken Grotesk
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 0.6875rem
    fontWeight: '700'
    lineHeight: 0.875rem
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-xxl: 3rem
---

## Brand & Style

The design system establishes a premium, bespoke operational interface for luxury hospitality point-of-sale and revenue management. It blends modern corporate clarity with the timeless prestige of a five-star grand hotel. The experience communicates effortless precision, quiet wealth, and high-velocity responsiveness.

The design movement is **Modern Luxury Corporate with Tactile Precision**:
- High-order typographic refinement paired with deliberate negative space.
- Architectural card structures framed by whisper-thin, calibrated borders.
- Controlled use of opulent warm brass and bullion gold accents against deep obsidian-navy anchors.
- Crisp executive telemetry: dense, instantly readable transactional metrics without visual friction or retail clutter.

## Colors

The palette balances deep naval structure with lustrous metallic accents and crisp daylight legibility:

- **Primary Canvas & Structural Anchors**: `#0B132B` (Obsidian Navy) and `#1C2541` (Deep Slate) form high-hierarchy containers, command bars, receipts, and primary CTA surfaces. `#3A506B` (Muted Slate) serves as secondary interactive states and subtle divider lines.
- **Luxury Metallic Palette**: `#C5A059` (Deep Warm Brass) functions as the core luxury accent for verified VIP badges, selected states, and focused data rings. `#D4AF37` (Rich Gold) and `#E5C378` (Champagne Highlight) are applied to fine line accents, active chart highlights, and hover micro-interactions.
- **Atmospheric Surfaces**: `#F8F9FA` forms the base workstation canvas, complemented by `#F1F4F8` for nested metric wells, subtle data tables, and elevated drawer panels.
- **Structural Borders**: `#E2E8F0` defines cards and split panes with sub-pixel sharpness.
- **Executive Telemetry & Indicators**:
  - Positive Performance: `#10B981` (Emerald Revenue Growth).
  - Negative & Overdue Alerts: `#EF4444` (Crimson Reversal / Comp / Void).
  - Attention / Pending Folio: `#D97706` (Amber Processing).

## Typography

The typographical pairing expresses the duality of fine hospitality: editorial heritage balanced with Swiss-style operational precision.

- **Headline Font (`Newsreader`)**: Evokes the prestige of grand hotel guest registers, private clubs, and Michelin-starred tasting menus. Used strictly for primary folio headings, screen titles, and revenue section intros.
- **Body & Label Font (`Hanken Grotesk`)**: Provides razor-sharp legibility on POS screens and sales analytics terminals. High x-height and clear numeric tabular data rendering make it ideal for order lines, ticket splits, and real-time reconciliation.
- **KPI Metrics**: Rendered in dense bold grotesk with negative tracking to convey stability and fiscal authority.
- **Micro Labels (`label-sm`)**: Styled in uppercase with wide tracking (`0.08em`) for data categorization (e.g., "ADR", "REVPAR", "ROOM 1402", "SPLIT BILL").

## Layout & Spacing

The layout is built upon a rigid 8px baseline rhythm across an adaptive fluid-grid architecture:

- **Desktop (1440px+)**: A three-pane cockpit layout:
  - 280px fixed navigational command rail (dark `#0B132B`).
  - Fluid 8-column main operational workspace with 24px (`space-lg`) gutters.
  - 380px contextual order terminal / folio drawer on the right.
- **Tablet Landscape (1024px - 1439px)**:
  - Collapsible navigation rail to 72px icon mode.
  - Adaptive 6-column grid with 16px (`space-md`) gutters.
  - Folio cart pinned to the bottom or accessible as an off-canvas slide-out sheet.
- **Mobile Handheld Terminal (375px - 768px)**:
  - Single-column linear flow with 16px outer margin.
  - Sticky bottom transaction action bar with safe area padding.
- **Rhythm Rules**: Internal component card paddings match standard steps: `space-lg` (24px) for prominent executive cards and `space-md` (16px) for compact data tables, order line items, and transaction logs.

## Elevation & Depth

Visual hierarchy leverages crisp hairline outlines, tonal surface stacking, and whisper-soft warm ambient diffusion:

- **Surface Tiers**:
  - *Tier 0 (Base Canvas)*: `#F8F9FA` flat background.
  - *Tier 1 (Resting Cards)*: Pure white `#FFFFFF` surface enclosed by a 1px solid `#E2E8F0` border.
  - *Tier 2 (Elevated Sheets & Floating Trays)*: `#FFFFFF` with ambient shadow `0 10px 25px -5px rgba(11, 19, 43, 0.05), 0 8px 10px -6px rgba(11, 19, 43, 0.03)`.
  - *Tier 3 (Active Modals & Checkout Folios)*: Multi-stage shadow with subtle brass tinting: `0 20px 35px -10px rgba(11, 19, 43, 0.12), 0 0 0 1px rgba(197, 160, 89, 0.25)`.
- **The Navy Anchor Rule**: High-order command bars and primary bill headers invert to `#0B132B` surfaces with hairline gold borders (`rgba(197, 160, 89, 0.35)`), creating immediate visual weight that pins the interface.

## Shapes

The geometric framework balances contemporary smoothness with tailored structural rigor:

- Base interface elements (inputs, small chips, dropdown items) use `0.5rem` (8px).
- Executive metric cards, billing tables, and POS grid modules utilize `rounded-xl` (`1rem` / 16px).
- Grand modals, folio drawers, and top-tier KPI summary containers apply `rounded-2xl` (`1.5rem` / 24px).
- Pure pill shapes (`rounded-full`) are reserved strictly for status badges, table indicators, avatar enclosures, and quick-filter buttons.

## Components

### Buttons & Interactive Controls
- **Primary Transaction Action**: Deep Obsidian Navy `#0B132B` fill, `#FFFFFF` text, subtle 1px border `rgba(197, 160, 89, 0.4)`, `rounded-lg`. Hover brings micro-glow with brass border intensification `#C5A059`.
- **Secondary Luxury Action**: Transparent fill with 1.5px `#C5A059` border, text `#C5A059`. Hover transitions to `#C5A059` fill with `#0B132B` text.
- **Tertiary / Utility Action**: `#F1F4F8` fill, `#1C2541` text, borderless. Hover shifts to `#E2E8F0`.

### KPI Metric Cards
- White `#FFFFFF` base, `1rem` radius, 1px `#E2E8F0` border.
- Top bar displays category label in `label-sm` with a right-aligned luxury brass icon or pill indicator.
- Metric value rendered in `kpi-metric` `#0B132B`.
- Delta baseline includes inline pill:
  - Growth: emerald background `rgba(16, 185, 129, 0.12)` with `#10B981` text (`+14.2%`).
  - Loss / Reversal: crimson background `rgba(239, 68, 68, 0.12)` with `#EF4444` text (`-3.1%`).
- Sparkline baseline rendered in rich brass `#C5A059` with subtle gradient area fade.

### Data Visualization Tokens
- **Bar Charts (Sales by Revenue Center - Dining, Bar, Spa, Cabana)**:
  - Neutral gridlines: `#E2E8F0` dashed (1px).
  - Primary bar fill: `#1C2541` with hover transition to `#C5A059`.
  - Comparison baseline bars: `#F1F4F8`.
  - Tooltips: `#0B132B` solid backdrop, `#FFFFFF` typography, 1px gold border.
- **Donut Charts (Folio Settlement / Payment Splits)**:
  - Stroke width: 14px with rounded end-caps.
  - Palettes: Credit (`#0B132B`), Room Charge (`#C5A059`), Cash (`#10B981`), House Account (`#3A506B`).
  - Center cutout houses total revenue in `headline-sm` with `label-sm` subtitle.

### Folio Lists & Line-Item Tables
- Row height: 48px standard, 56px expanded.
- Alternating subtle row hover: `#F8F9FA`.
- Bottom border: 1px solid `#F1F4F8`.
- Tabular numeric alignment (right-aligned for currency, units, tax percentages).

### Tax & Surcharge Breakdown Module
- Inset container using `#F1F4F8` with `rounded-xl`.
- High-contrast two-column key-value ledger:
  - Subtotal, Luxury Occupancy Tax (8.5%), City Resort Surcharge (3.2%), Gratuity (18%).
  - Grand Total highlighted via `#0B132B` container with warm gold `#E5C378` typographic emphasis.

### Form Inputs & Terminal Numpads
- Background: `#FFFFFF`, border: 1px `#E2E8F0`. Focus state: 1.5px `#C5A059` with zero shadow blur.
- Numerical POS keypads feature crisp square-proportional touch targets with active press compression feedback (`scale: 0.98`).